# FUNCIONALIDADES EXCEL - VERSÃO 20251016_1342

## 🆕 Novidades desta versão

### Análise Avançada de Arquivos Excel
- **Detecção automática de pandas**: Verifica se pandas está instalado
- **Instalação automática**: Instala pandas e openpyxl se necessário
- **Análise multi-planilha**: Examina todas as planilhas do arquivo
- **Estatísticas detalhadas**: Contagem de linhas, colunas, células
- **Detecção de dados ausentes**: Calcula porcentagem de células vazias
- **Validação de formato**: Verifica integridade do formato Excel

### Como usar as funcionalidades Excel

#### Modo Interativo
```bash
python3 verificador_interativo.py
```
- Escolha opção "s" para habilitar análise Excel avançada
- Sistema perguntará se deseja auto-instalar dependências
- Análise automática de todos arquivos .xlsx/.xls encontrados

#### Modo Programático
```python
from script import FileIntegrityChecker

# Com auto-instalação de dependências
checker = FileIntegrityChecker(['/caminho/para/arquivos'], 
                               auto_install_excel=True)

# Verificar arquivo específico
result = checker.check_file_integrity('/arquivo.xlsx')

# Acessar informações Excel
if 'specific_checks' in result:
    checks = result['specific_checks']
    print("Planilhas:", checks.get('sheet_names', []))
    print("Total células:", checks.get('total_cells', 0))
```

### Estrutura de resposta Excel

Exemplo de resposta JSON:
- file_name: "exemplo.xlsx"
- integrity_status: "INTACT"  
- specific_checks:
  - format_valid: true
  - verification_level: "advanced"
  - sheets_count: 3
  - pandas_version: "2.2.3"
  - sheet_names: ["Planilha1", "Dados", "Resumo"]
  - sheets_info: informações detalhadas por planilha
  - total_cells: 1500

## 🔧 Dependências Excel

### Automática (Recomendada)
```bash
python3 verificador_interativo.py
# Selecione "s" para Excel e "s" para auto-instalar
```

### Manual
```bash
pip3 install pandas openpyxl
```

## 🚀 Performance

- **Arquivos pequenos (<10MB)**: Análise completa em ~1-2 segundos
- **Arquivos médios (10-100MB)**: Análise completa em ~3-10 segundos  
- **Arquivos grandes (>100MB)**: Análise básica (sem pandas) em ~1-2 segundos

## 🛠️ Troubleshooting

### Pandas não instala automaticamente
```bash
# Instalar manualmente
pip3 install --upgrade pip
pip3 install pandas openpyxl
```

### Erro "File is not a zip file"
- Arquivo Excel está corrompido
- Verificador reportará como "CORRUPTED"
- Recomenda-se recuperar de backup

### Performance lenta
- Desabilite análise Excel avançada para arquivos muito grandes
- Use modo básico: auto_install_excel=False

---
📅 Versão: 20251016_1342
🔧 Python 3.6+ compatível
📦 Distribuição standalone disponível

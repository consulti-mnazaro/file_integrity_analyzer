#!/usr/bin/env python3
"""
Criar um arquivo Excel real para testar as funcionalidades
"""

import pandas as pd
import tempfile
import os
from script import FileIntegrityChecker

def criar_teste_excel_real():
    """Criar e testar arquivo Excel real"""
    
    print("📊 CRIANDO ARQUIVO EXCEL REAL PARA TESTE")
    print("=" * 42)
    
    # Criar dados de exemplo
    dados = {
        'Nome': ['João Silva', 'Maria Santos', 'Pedro Costa', 'Ana Oliveira'],
        'Idade': [30, 25, 35, 28],
        'Cidade': ['São Paulo', 'Rio de Janeiro', 'Belo Horizonte', 'Salvador'],
        'Salario': [5000, 4500, 5500, 4800],
        'Ativo': [True, True, False, True]
    }
    
    df = pd.DataFrame(dados)
    
    # Criar arquivo temporário
    test_dir = tempfile.mkdtemp()
    excel_file = os.path.join(test_dir, "funcionarios.xlsx")
    
    print(f"Criando arquivo: {excel_file}")
    
    # Criar arquivo Excel com múltiplas planilhas
    with pd.ExcelWriter(excel_file, engine='openpyxl') as writer:
        df.to_excel(writer, sheet_name='Funcionarios', index=False)
        
        # Segunda planilha com dados financeiros
        df_financeiro = pd.DataFrame({
            'Mes': ['Janeiro', 'Fevereiro', 'Março'],
            'Receita': [10000, 12000, 11000],
            'Despesas': [8000, 9000, 8500]
        })
        df_financeiro.to_excel(writer, sheet_name='Financeiro', index=False)
        
        # Terceira planilha vazia
        pd.DataFrame().to_excel(writer, sheet_name='Vazia', index=False)
    
    print("✅ Arquivo Excel criado com sucesso!")
    
    # Testar verificador
    print(f"\n🔍 Testando verificador...")
    checker = FileIntegrityChecker([test_dir], auto_install_excel=True)
    
    result = checker.check_file_integrity(excel_file)
    
    print("\n📊 RESULTADO DA VERIFICAÇÃO:")
    print("=" * 32)
    
    # Informações básicas
    print(f"Arquivo: {result['file_name']}")
    print(f"Tamanho: {result['file_size']} bytes")
    print(f"Status: {result['integrity_status']}")
    print(f"Hash MD5: {result['md5_hash'][:16]}...")
    
    # Verificações específicas Excel
    if 'specific_checks' in result:
        checks = result['specific_checks']
        print(f"\\nVerificação Excel:")
        print(f"  Formato válido: {checks.get('format_valid', 'N/A')}")
        print(f"  Nível de verificação: {checks.get('verification_level', 'N/A')}")
        print(f"  Número de planilhas: {checks.get('sheets_count', 'N/A')}")
        
        if 'pandas_version' in checks:
            print(f"  Pandas versão: {checks['pandas_version']}")
        
        if 'sheet_names' in checks:
            print(f"  Planilhas: {', '.join(checks['sheet_names'])}")
        
        if 'sheets_info' in checks:
            print(f"\\n📋 Detalhes das planilhas:")
            for sheet_name, info in checks['sheets_info'].items():
                if 'error' not in info:
                    print(f"    {sheet_name}:")
                    print(f"      Linhas: {info.get('rows', 0)}")
                    print(f"      Colunas: {info.get('columns', 0)}")
                    print(f"      Células: {info.get('cells', 0)}")
                    print(f"      Dados ausentes: {info.get('missing_cells', 0)} ({info.get('missing_percentage', 0)}%)")
                else:
                    print(f"    {sheet_name}: ERRO - {info['error']}")
        
        if 'total_cells' in checks:
            print(f"\\n📈 Total de células analisadas: {checks['total_cells']}")
        
        if 'error' in checks:
            print(f"\\n❌ Erro: {checks['error']}")
        elif 'warning' in checks:
            print(f"\\n⚠️  Aviso: {checks['warning']}")
    
    # Limpar
    os.remove(excel_file)
    os.rmdir(test_dir)
    
    print(f"\\n✅ Teste completo! Arquivo temporário removido.")

if __name__ == "__main__":
    criar_teste_excel_real()
#!/bin/bash
# Instalação rápida das dependências Excel

echo "🚀 INSTALAÇÃO RÁPIDA - VERIFICADOR INTEGRIDADE EXCEL"
echo "=================================================="

echo "📦 Verificando Python..."
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 não encontrado. Instale Python 3.6+ primeiro."
    exit 1
fi

echo "✅ Python encontrado: $(python3 --version)"

echo "📦 Instalando dependências Excel..."
pip3 install --user pandas openpyxl

echo "🧪 Testando instalação..."
python3 -c "import pandas, openpyxl; print('✅ Dependências Excel instaladas com sucesso!')"

echo "🎉 Instalação concluída! Execute:"
echo "   python3 verificador_interativo.py"

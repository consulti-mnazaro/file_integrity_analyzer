# Verificador de Integridade de Arquivos

## Descrição
Script Python para verificar a integridade de arquivos em diretórios, detectando arquivos corrompidos, inacessíveis ou com problemas de formato.

## Funcionalidades

### Verificações Gerais
- ✅ Acessibilidade do arquivo
- ✅ Permissões de leitura
- ✅ Cálculo de hash MD5 e SHA256
- ✅ Informações básicas (tamanho, data de modificação)

### Verificações Específicas por Tipo de Arquivo
- **CSV**: Verificação de formato, contagem de linhas/colunas, detecção de encoding
- **JSON**: Validação de sintaxe JSON
- **Excel (.xlsx/.xls)**: Verificação de planilhas válidas
- **PDF**: Verificação de cabeçalho e estrutura
- **Texto (.txt)**: Verificação de encoding e contagem de linhas
- **Python (.py)**: Verificação de sintaxe
- **SQL (.sql)**: Análise básica de statements
- **XML**: Verificação de estrutura bem formada
- **ZIP**: Teste de integridade do arquivo compactado
- **RAR**: Verificação de assinatura

## Uso

### Linha de Comando
```bash
# Verificar um diretório
python script.py /caminho/para/diretorio

# Verificar múltiplos diretórios
python script.py /dir1 /dir2 /dir3

# Especificar formato de saída
python script.py /diretorio --format csv

# Especificar nome do arquivo de saída
python script.py /diretorio --output meu_relatorio
```

### Uso Programático
```python
from script import FileIntegrityChecker

# Criar verificador
checker = FileIntegrityChecker(['/caminho/diretorio'], output_format='json')

# Executar verificação
checker.scan_directories()

# Gerar relatório
checker.generate_report('relatorio')

# Verificar arquivo específico
resultado = checker.check_file_integrity('/caminho/arquivo.csv')
print(resultado['integrity_status'])  # INTACT, CORRUPTED, INACCESSIBLE, UNKNOWN
```

## Exemplos de Uso

### 1. Verificação Básica
```bash
python script.py ../carga_dados_fixos_dash_custos
```

### 2. Verificação com Múltiplos Diretórios
```bash
python script.py ../carga_dados_fixos_dash_custos ../analise_compras_custos_seletiva --format csv
```

### 3. Usar o Script de Exemplo
```bash
python exemplo_uso.py
```

## Arquivos de Saída

### JSON Report (padrão)
- `integrity_report_YYYYMMDD_HHMMSS.json`: Relatório completo com todos os detalhes
- `integrity_report_YYYYMMDD_HHMMSS_summary.txt`: Sumário textual

### CSV Report
- `integrity_report_YYYYMMDD_HHMMSS.csv`: Dados tabulares para análise
- `integrity_report_YYYYMMDD_HHMMSS_summary.txt`: Sumário textual

## Status de Integridade

- **INTACT**: Arquivo íntegro e sem problemas
- **CORRUPTED**: Arquivo corrompido ou com problemas de formato
- **INACCESSIBLE**: Arquivo não pode ser acessado (permissões, não existe)
- **UNKNOWN**: Status não determinado

## Dependências Opcionais

Para verificações avançadas, instale:
```bash
pip install pandas openpyxl
```

## Log de Execução

O script gera automaticamente um log em `file_integrity_check.log` com informações detalhadas da execução.

## Exemplos de Relatório

### Sumário
```
=== RELATÓRIO DE INTEGRIDADE DE ARQUIVOS ===

Data da verificação: 2025-10-16T10:30:00
Total de arquivos verificados: 150
Arquivos íntegros: 145
Arquivos corrompidos: 3
Arquivos inacessíveis: 2

Percentual de arquivos íntegros: 96.7%
Percentual de arquivos corrompidos: 2.0%

=== ARQUIVOS CORROMPIDOS ===
- /path/arquivo_corrompido.csv
  Erro: CSV inválido: linha 100 tem número incorreto de campos
```

## Casos de Uso Típicos

1. **Auditoria de Integridade**: Verificar se arquivos de backup estão íntegros
2. **Validação Pós-Transferência**: Confirmar que arquivos foram transferidos corretamente
3. **Detecção de Corrupção**: Identificar arquivos corrompidos antes de processamento
4. **Monitoramento de Sistema**: Verificação periódica de integridade de dados
5. **Migração de Dados**: Validar integridade antes e após migração
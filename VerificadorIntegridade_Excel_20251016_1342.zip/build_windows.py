#!/usr/bin/env python3
"""
Build para Windows - Executável .exe
Cria executável standalone para ambiente Windows
"""

import subprocess
import sys
import os
import shutil
from datetime import datetime

def criar_versao_windows():
    """Criar versão específica para Windows"""
    
    print("🪟 Criando versão para Windows...")
    
    # Script otimizado para Windows
    script_windows = '''#!/usr/bin/env python3
"""
Verificador de Integridade - Versão Windows Standalone
Executável otimizado para ambiente Windows
"""

import os
import sys
import hashlib
import json
import csv
from datetime import datetime
from pathlib import Path
import re
import zipfile
import argparse
import logging

# Configurar paths para executável Windows
if getattr(sys, 'frozen', False):
    application_path = Path(sys.executable).parent
else:
    application_path = Path(__file__).parent

sys.path.insert(0, str(application_path))

class FileIntegrityChecker:
    """Classe para verificação de integridade - Windows"""
    
    def __init__(self, directories, output_format='txt'):
        self.directories = directories
        self.output_format = output_format
        self.results = []
        self.summary = {
            'total_files': 0,
            'intact_files': 0,
            'corrupted_files': 0,
            'inaccessible_files': 0,
            'scan_date': datetime.now().isoformat()
        }
        
        # Handlers básicos para Windows
        self.file_handlers = {
            '.csv': self._check_csv_file,
            '.json': self._check_json_file,
            '.txt': self._check_text_file,
            '.py': self._check_python_file,
            '.sql': self._check_sql_file,
            '.xml': self._check_xml_file,
            '.zip': self._check_zip_file,
            '.pdf': self._check_pdf_file,
            '.xlsx': self._check_excel_file,
            '.docx': self._check_docx_file,
            '.bat': self._check_batch_file,
            '.ps1': self._check_powershell_file
        }
    
    def calculate_file_hash(self, file_path, algorithm='md5'):
        """Calcular hash do arquivo"""
        try:
            hash_func = hashlib.new(algorithm)
            with open(file_path, 'rb') as f:
                for chunk in iter(lambda: f.read(4096), b""):
                    hash_func.update(chunk)
            return hash_func.hexdigest()
        except Exception:
            return None
    
    def _check_basic_accessibility(self, file_path):
        """Verificação básica - Windows"""
        result = {
            'file_path': file_path,
            'file_name': os.path.basename(file_path),
            'file_size': 0,
            'is_accessible': False,
            'is_readable': False,
            'last_modified': '',
            'error': None
        }
        
        try:
            if not os.path.exists(file_path):
                result['error'] = 'Arquivo não encontrado'
                return result
            
            stat_info = os.stat(file_path)
            result['file_size'] = stat_info.st_size
            result['last_modified'] = datetime.fromtimestamp(stat_info.st_mtime).isoformat()
            result['is_accessible'] = True
            
            if os.access(file_path, os.R_OK):
                result['is_readable'] = True
        except Exception as e:
            result['error'] = str(e)
        
        return result
    
    def _check_csv_file(self, file_path):
        """Verificação CSV para Windows"""
        check = {'format_valid': False, 'rows_count': 0}
        try:
            encodings = ['utf-8', 'latin1', 'cp1252', 'utf-8-sig']  # BOM para Windows
            for encoding in encodings:
                try:
                    with open(file_path, 'r', encoding=encoding, newline='') as f:
                        csv_reader = csv.reader(f)
                        rows = list(csv_reader)
                        check['format_valid'] = True
                        check['rows_count'] = len(rows)
                        check['encoding'] = encoding
                        break
                except UnicodeDecodeError:
                    continue
        except Exception as e:
            check['error'] = str(e)
        return check
    
    def _check_json_file(self, file_path):
        """Verificação JSON"""
        check = {'format_valid': False}
        try:
            encodings = ['utf-8', 'utf-8-sig', 'cp1252']
            for encoding in encodings:
                try:
                    with open(file_path, 'r', encoding=encoding) as f:
                        json.load(f)
                        check['format_valid'] = True
                        check['json_valid'] = True
                        check['encoding'] = encoding
                        break
                except UnicodeDecodeError:
                    continue
        except json.JSONDecodeError as e:
            check['error'] = f"JSON inválido: {e}"
        except Exception as e:
            check['error'] = str(e)
        return check
    
    def _check_text_file(self, file_path):
        """Verificação texto para Windows"""
        check = {'format_valid': False, 'lines_count': 0}
        try:
            encodings = ['utf-8', 'utf-8-sig', 'latin1', 'cp1252']
            for encoding in encodings:
                try:
                    with open(file_path, 'r', encoding=encoding) as f:
                        lines = f.readlines()
                        check['format_valid'] = True
                        check['lines_count'] = len(lines)
                        check['encoding'] = encoding
                        break
                except UnicodeDecodeError:
                    continue
        except Exception as e:
            check['error'] = str(e)
        return check
    
    def _check_python_file(self, file_path):
        """Verificação Python"""
        check = {'format_valid': False, 'syntax_valid': False}
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            compile(content, file_path, 'exec')
            check['format_valid'] = True
            check['syntax_valid'] = True
        except SyntaxError as e:
            check['format_valid'] = True
            check['syntax_error'] = str(e)
        except Exception as e:
            check['error'] = str(e)
        return check
    
    def _check_sql_file(self, file_path):
        """Verificação SQL"""
        check = {'format_valid': False}
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            check['format_valid'] = True
            check['lines_count'] = len(content.splitlines())
        except Exception as e:
            check['error'] = str(e)
        return check
    
    def _check_xml_file(self, file_path):
        """Verificação XML"""
        check = {'format_valid': False}
        try:
            import xml.etree.ElementTree as ET
            ET.parse(file_path)
            check['format_valid'] = True
            check['well_formed'] = True
        except Exception as e:
            check['error'] = str(e)
        return check
    
    def _check_zip_file(self, file_path):
        """Verificação ZIP"""
        check = {'format_valid': False}
        try:
            with zipfile.ZipFile(file_path, 'r') as zip_file:
                bad_file = zip_file.testzip()
                check['format_valid'] = True
                check['is_corrupted'] = bad_file is not None
                check['files_count'] = len(zip_file.namelist())
        except Exception as e:
            check['error'] = str(e)
        return check
    
    def _check_pdf_file(self, file_path):
        """Verificação PDF"""
        check = {'format_valid': False}
        try:
            with open(file_path, 'rb') as f:
                header = f.read(8)
                if header.startswith(b'%PDF-'):
                    check['format_valid'] = True
                    check['pdf_version'] = header.decode('ascii', errors='ignore')
        except Exception as e:
            check['error'] = str(e)
        return check
    
    def _check_excel_file(self, file_path):
        """Verificação Excel básica"""
        check = {'format_valid': False}
        try:
            with open(file_path, 'rb') as f:
                header = f.read(8)
                # Verificar assinatura ZIP (xlsx) ou assinatura OLE (xls)
                if header.startswith(b'PK\\x03\\x04') or header.startswith(b'\\xd0\\xcf\\x11\\xe0'):
                    check['format_valid'] = True
                    check['excel_format'] = 'xlsx' if header.startswith(b'PK') else 'xls'
        except Exception as e:
            check['error'] = str(e)
        return check
    
    def _check_docx_file(self, file_path):
        """Verificação Word DOCX"""
        check = {'format_valid': False}
        try:
            with open(file_path, 'rb') as f:
                header = f.read(4)
                if header == b'PK\\x03\\x04':  # ZIP signature
                    check['format_valid'] = True
                    check['docx_format'] = True
        except Exception as e:
            check['error'] = str(e)
        return check
    
    def _check_batch_file(self, file_path):
        """Verificação arquivo .bat"""
        check = {'format_valid': False}
        try:
            with open(file_path, 'r', encoding='cp1252') as f:
                content = f.read()
            check['format_valid'] = True
            check['lines_count'] = len(content.splitlines())
            check['batch_file'] = True
        except Exception as e:
            check['error'] = str(e)
        return check
    
    def _check_powershell_file(self, file_path):
        """Verificação arquivo PowerShell .ps1"""
        check = {'format_valid': False}
        try:
            with open(file_path, 'r', encoding='utf-8-sig') as f:
                content = f.read()
            check['format_valid'] = True
            check['lines_count'] = len(content.splitlines())
            check['powershell_file'] = True
        except Exception as e:
            check['error'] = str(e)
        return check
    
    def check_file_integrity(self, file_path):
        """Verificar integridade de um arquivo"""
        result = self._check_basic_accessibility(file_path)
        
        if not result['is_accessible']:
            result['integrity_status'] = 'INACCESSIBLE'
            return result
        
        result['md5_hash'] = self.calculate_file_hash(file_path, 'md5')
        
        file_ext = Path(file_path).suffix.lower()
        if file_ext in self.file_handlers:
            specific_check = self.file_handlers[file_ext](file_path)
            result['specific_checks'] = specific_check
        else:
            result['specific_checks'] = {'format': 'unknown'}
        
        # Determinar status
        if result['is_readable']:
            if result['file_size'] == 0:
                result['integrity_status'] = 'UNKNOWN'
            elif 'specific_checks' in result and 'error' not in result['specific_checks']:
                result['integrity_status'] = 'INTACT'
            elif 'specific_checks' in result and 'error' in result['specific_checks']:
                result['integrity_status'] = 'CORRUPTED'
            else:
                result['integrity_status'] = 'INTACT'
        else:
            result['integrity_status'] = 'CORRUPTED'
        
        return result
    
    def scan_directories(self):
        """Escanear diretórios"""
        for directory in self.directories:
            if not os.path.exists(directory):
                continue
            
            for root, dirs, files in os.walk(directory):
                for file in files:
                    file_path = os.path.join(root, file)
                    try:
                        result = self.check_file_integrity(file_path)
                        self.results.append(result)
                        
                        self.summary['total_files'] += 1
                        if result['integrity_status'] == 'INTACT':
                            self.summary['intact_files'] += 1
                        elif result['integrity_status'] == 'CORRUPTED':
                            self.summary['corrupted_files'] += 1
                        elif result['integrity_status'] == 'INACCESSIBLE':
                            self.summary['inaccessible_files'] += 1
                            
                    except Exception:
                        continue
    
    def generate_text_report(self, output_name):
        """Gerar relatório em texto - Windows"""
        report_file = f"{output_name}.txt"
        
        with open(report_file, 'w', encoding='utf-8-sig') as f:  # BOM para Windows
            f.write("=" * 80 + "\\n")
            f.write("                RELATORIO DE INTEGRIDADE DE ARQUIVOS\\n")
            f.write("=" * 80 + "\\n\\n")
            
            f.write(f"Data: {self.summary['scan_date']}\\n")
            f.write(f"Total: {self.summary['total_files']}\\n")
            f.write(f"Integros: {self.summary['intact_files']}\\n")
            f.write(f"Corrompidos: {self.summary['corrupted_files']}\\n")
            f.write(f"Inacessiveis: {self.summary['inaccessible_files']}\\n\\n")
            
            # Arquivos corrompidos
            corrupted = [r for r in self.results if r['integrity_status'] == 'CORRUPTED']
            if corrupted:
                f.write("ARQUIVOS CORROMPIDOS:\\n")
                f.write("-" * 20 + "\\n")
                for i, result in enumerate(corrupted, 1):
                    f.write(f"{i}. {result['file_path']}\\n")
                    if result.get('error'):
                        f.write(f"   Erro: {result['error']}\\n")
                f.write("\\n")
            
            # Lista completa
            f.write("LISTA COMPLETA:\\n")
            f.write("-" * 15 + "\\n")
            status_symbols = {
                'INTACT': '[OK]',        # Símbolos compatíveis com Windows
                'CORRUPTED': '[ERRO]', 
                'INACCESSIBLE': '[INAC]',
                'UNKNOWN': '[?]'
            }
            
            for result in sorted(self.results, key=lambda x: x['file_path']):
                symbol = status_symbols.get(result['integrity_status'], '[?]')
                f.write(f"{symbol} {result['file_path']}\\n")

class InteractiveFileChecker:
    """Interface interativa para Windows"""
    
    def __init__(self):
        self.directories = []
        self.output_name = None
    
    def print_header(self):
        print("=" * 60)
        print("       VERIFICADOR DE INTEGRIDADE DE ARQUIVOS")
        print("                  Versao Windows")
        print("=" * 60)
        print()
    
    def get_directories(self):
        while True:
            if not self.directories:
                print("Digite o diretorio para verificar:")
                print("Exemplo: C:\\\\Users\\\\Usuario\\\\Documents")
                user_input = input(">>> ").strip()
                
                if not user_input:
                    print("ERRO: Diretorio obrigatorio!")
                    continue
                
                # Normalizar path para Windows
                user_input = os.path.normpath(user_input)
                
                if os.path.exists(user_input):
                    self.directories.append(os.path.abspath(user_input))
                    print(f"OK: Adicionado: {user_input}")
                    break
                else:
                    print(f"ERRO: Diretorio nao encontrado: {user_input}")
            else:
                break
    
    def get_output_name(self):
        print("\\nNome do relatorio (Enter para automatico):")
        output_input = input(">>> ").strip()
        
        if not output_input:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            self.output_name = f"relatorio_integridade_{timestamp}"
        else:
            # Remover caracteres inválidos para Windows
            invalid_chars = '<>:"/\\\\|?*'
            for char in invalid_chars:
                output_input = output_input.replace(char, '_')
            self.output_name = output_input
        
        print(f"OK: Relatorio: {self.output_name}.txt")
    
    def execute_check(self):
        print("\\nExecutando verificacao...")
        
        checker = FileIntegrityChecker(self.directories)
        checker.scan_directories()
        checker.generate_text_report(self.output_name)
        
        print(f"\\nConcluido!")
        print(f"Total: {checker.summary['total_files']}")
        print(f"Integros: {checker.summary['intact_files']}")
        print(f"Corrompidos: {checker.summary['corrupted_files']}")
        print(f"\\nRelatorio: {self.output_name}.txt")
    
    def run(self):
        try:
            self.print_header()
            self.get_directories()
            self.get_output_name()
            
            print("\\nProsseguir? (s/n): ", end="")
            resposta = input().strip().lower()
            if resposta in ['', 's', 'sim', 'y', 'yes']:
                self.execute_check()
            else:
                print("Cancelado.")
                
        except KeyboardInterrupt:
            print("\\nCancelado pelo usuario")
        except Exception as e:
            print(f"\\nErro: {e}")

def main():
    """Funcao principal"""
    try:
        print("Iniciando Verificador de Integridade...")
        checker = InteractiveFileChecker()
        checker.run()
        print("\\nPressione Enter para sair...")
        input()
    except Exception as e:
        print(f"Erro: {e}")
        print("Pressione Enter para sair...")
        input()

if __name__ == "__main__":
    main()
'''
    
    with open('verificador_windows.py', 'w', encoding='utf-8') as f:
        f.write(script_windows)
    
    print("✅ Script Windows criado: verificador_windows.py")
    return 'verificador_windows.py'

def build_windows():
    """Build para Windows com configurações específicas"""
    
    print("🪟 BUILD PARA WINDOWS - EXECUTÁVEL .EXE")
    print("=" * 42)
    
    # 1. Limpar builds anteriores
    if os.path.exists('build'):
        shutil.rmtree('build')
    if os.path.exists('dist'):
        shutil.rmtree('dist')
    
    # 2. Criar versão para Windows
    script_windows = criar_versao_windows()
    
    # 3. Verificar se PyInstaller está instalado
    try:
        import PyInstaller
        print(f"✅ PyInstaller encontrado: {PyInstaller.__version__}")
    except ImportError:
        print("📦 Instalando PyInstaller...")
        subprocess.check_call([sys.executable, '-m', 'pip', 'install', 'pyinstaller>=6.0'])
    
    # 4. Build com configurações para Windows
    print("\\n🏗️  Criando executável .exe para Windows...")
    
    cmd = [
        sys.executable, '-m', 'PyInstaller',
        '--onefile',                    # Arquivo único
        '--console',                    # Interface console
        '--name=VerificadorIntegridade_Windows',
        '--clean',
        '--noconfirm',
        '--distpath=dist',
        '--workpath=build',
        '--specpath=.',
        
        # Ícone (se disponível)
        # '--icon=icon.ico',
        
        # Otimizações específicas
        '--exclude-module=pandas',
        '--exclude-module=numpy',
        '--exclude-module=matplotlib',
        '--exclude-module=torch',
        '--exclude-module=scipy',
        '--exclude-module=PIL',
        '--exclude-module=cv2',
        '--exclude-module=sklearn',
        '--exclude-module=tensorflow',
        '--exclude-module=tkinter',
        '--exclude-module=PyQt5',
        '--exclude-module=PyQt6',
        '--exclude-module=PySide2',
        '--exclude-module=PySide6',
        '--exclude-module=wx',
        
        # Configurações Windows específicas
        '--exclude-module=readline',    # Específico Linux
        '--exclude-module=termios',     # Específico Linux/Unix
        
        script_windows
    ]
    
    print("Executando PyInstaller...")
    resultado = subprocess.run(cmd)
    
    if resultado.returncode == 0:
        # Verificar se o executável foi criado
        executavel_exe = 'dist/VerificadorIntegridade_Windows.exe'
        executavel_sem_ext = 'dist/VerificadorIntegridade_Windows'
        
        # PyInstaller no Linux cria sem extensão, vamos renomear
        if os.path.exists(executavel_sem_ext):
            os.rename(executavel_sem_ext, executavel_exe)
        
        if os.path.exists(executavel_exe):
            tamanho = os.path.getsize(executavel_exe) / (1024 * 1024)  # MB
            
            print(f"\\n✅ EXECUTÁVEL WINDOWS CRIADO!")
            print(f"📁 Local: {executavel_exe}")
            print(f"📏 Tamanho: {tamanho:.1f} MB")
            print(f"🪟 Tipo: Executável Windows (.exe)")
            print(f"\\n💡 Para Windows: VerificadorIntegridade_Windows.exe")
            
            # Criar documentação Windows
            criar_doc_windows(executavel_exe, tamanho)
            
            # Criar script de teste Windows
            criar_script_teste_windows()
            
            return True
        else:
            print("❌ Executável Windows não encontrado")
            return False
    else:
        print("❌ Erro no build Windows")
        return False

def criar_doc_windows(executavel, tamanho_mb):
    """Criar documentação específica para Windows"""
    
    doc = f"""# 🪟 VERIFICADOR DE INTEGRIDADE - WINDOWS EXECUTÁVEL

## ✅ Informações do Executável Windows
- **Arquivo**: {os.path.basename(executavel)}
- **Tamanho**: {tamanho_mb:.1f} MB
- **Tipo**: Executável Windows (.exe)
- **Compilado**: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}

## 🎯 Características Windows
✅ **NÃO requer Python** instalado no Windows
✅ **Arquivo único .exe** - baixar e executar
✅ **Interface CMD/PowerShell** nativa
✅ **Suporte a caracteres especiais** (UTF-8 com BOM)
✅ **Paths Windows** (C:\\\\, D:\\\\, etc.)

## 🖥️ Como Usar no Windows

### Método 1: Clique duplo
1. Baixar o arquivo .exe
2. Clicar duas vezes no arquivo
3. Seguir as instruções na tela

### Método 2: Prompt de Comando
```cmd
# Navegar até a pasta do executável
cd C:\\\\caminho\\\\para\\\\o\\\\arquivo

# Executar
VerificadorIntegridade_Windows.exe
```

### Método 3: PowerShell
```powershell
# Navegar até a pasta
Set-Location "C:\\\\caminho\\\\para\\\\o\\\\arquivo"

# Executar
.\\\\VerificadorIntegridade_Windows.exe
```

## 📋 Fluxo de Uso Windows
1. Execute o arquivo .exe
2. Digite o caminho do diretório (ex: C:\\\\Users\\\\Joao\\\\Documents)
3. Digite nome do relatório ou Enter para automático
4. Confirme com 's' ou Enter
5. ✅ Relatório .txt gerado na mesma pasta

## 🔍 Exemplo de Caminhos Windows
```
C:\\\\Users\\\\%USERNAME%\\\\Documents
D:\\\\Projetos\\\\MeuProjeto
\\\\\\\\servidor\\\\compartilhamento\\\\pasta
C:\\\\temp
```

## 📊 Arquivos Suportados (Windows)
- **Documentos**: .txt, .docx, .pdf
- **Planilhas**: .csv, .xlsx, .xls
- **Código**: .py, .sql, .json, .xml
- **Scripts**: .bat, .ps1, .cmd
- **Compactados**: .zip, .rar (básico)
- **Qualquer arquivo**: verificação geral

## 🆘 Solução de Problemas Windows

### Windows Defender/Antivírus bloqueia
1. Clicar em "Mais informações"
2. Clicar em "Executar mesmo assim"
3. Ou adicionar exceção no antivírus

### "Este aplicativo não pode ser executado"
- Arquivo pode estar corrompido no download
- Tentar baixar novamente
- Verificar se é Windows 64-bit

### Erro de permissão
1. Clicar com botão direito no .exe
2. "Executar como administrador"

### Caracteres estranhos no relatório
- Normal - relatório usa UTF-8
- Abrir com Notepad++ ou similar
- Ou usar Bloco de Notas padrão

## 📈 Status no Relatório Windows
- **[OK]** - Arquivo íntegro
- **[ERRO]** - Arquivo corrompido
- **[INAC]** - Arquivo inacessível  
- **[?]** - Status indeterminado

## 🚀 Distribuição
### Para compartilhar:
1. Enviar apenas o arquivo .exe ({tamanho_mb:.1f} MB)
2. Destinatário executa direto
3. Não precisa instalar nada

### Por email:
- Arquivo pequeno ({tamanho_mb:.1f} MB)
- Pode ir como anexo
- Mencionar que é seguro (falso positivo comum)

### Por pendrive:
- Copiar o .exe
- Executar em qualquer Windows
- Funciona offline

## 🔒 Segurança
- ✅ Código limpo e auditável
- ✅ Sem conexão com internet
- ✅ Não modifica sistema
- ✅ Apenas lê arquivos
- ✅ Relatórios locais apenas

## 🎉 Vantagens da Versão Windows
- **Nativo** - integração completa com Windows
- **Rápido** - otimizado para sistema
- **Compatível** - funciona em Windows 10/11
- **Simples** - interface familiar
- **Portable** - não instala nada

---

**Testado em**: Windows 10/11 64-bit
**Criado em**: {datetime.now().strftime('%d/%m/%Y %H:%M')}
"""
    
    doc_file = f"{executavel}_GUIA_WINDOWS.txt"
    with open(doc_file, 'w', encoding='utf-8') as f:
        f.write(doc)
    
    print(f"📋 Documentação Windows criada: {os.path.basename(doc_file)}")

def criar_script_teste_windows():
    """Criar script para testar no Windows"""
    
    batch_test = '''@echo off
echo ===================================
echo TESTE DO VERIFICADOR - WINDOWS
echo ===================================
echo.

echo Criando arquivos de teste...
mkdir test_windows 2>nul

echo Este eh um arquivo de teste > test_windows\\arquivo_teste.txt
echo nome,idade,cidade > test_windows\\planilha.csv
echo João,30,São Paulo >> test_windows\\planilha.csv
echo {"nome": "teste", "valor": 123} > test_windows\\dados.json

echo.
echo Arquivos criados em: test_windows\\
echo.
echo Execute o verificador e use o caminho:
echo %CD%\\test_windows
echo.
pause
'''
    
    with open('teste_windows.bat', 'w', encoding='cp1252') as f:
        f.write(batch_test)
    
    print("📝 Script de teste Windows criado: teste_windows.bat")

if __name__ == "__main__":
    build_windows()
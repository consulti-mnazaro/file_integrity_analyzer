#!/usr/bin/env python3
"""
Build Otimizado - Executável mínimo e leve
Remove dependências desnecessárias para reduzir tamanho
"""

import subprocess
import sys
import os
import shutil

def criar_versao_minima():
    """Criar versão mínima do verificador sem dependências pesadas"""
    
    print("📦 Criando versão mínima...")
    
    # Script otimizado sem imports pesados
    script_minimo = '''#!/usr/bin/env python3
"""
Verificador de Integridade - Versão Mínima Standalone
Versão otimizada sem dependências pesadas
"""

import os
import sys
import hashlib
import json
import csv
from datetime import datetime
from pathlib import Path
import re
import zipfile
import argparse
import logging

# Configurar paths para executável
if getattr(sys, 'frozen', False):
    application_path = Path(sys.executable).parent
else:
    application_path = Path(__file__).parent

sys.path.insert(0, str(application_path))

class FileIntegrityChecker:
    """Classe minima para verificação de integridade"""
    
    def __init__(self, directories, output_format='txt'):
        self.directories = directories
        self.output_format = output_format
        self.results = []
        self.summary = {
            'total_files': 0,
            'intact_files': 0,
            'corrupted_files': 0,
            'inaccessible_files': 0,
            'scan_date': datetime.now().isoformat()
        }
        
        # Handlers básicos apenas
        self.file_handlers = {
            '.csv': self._check_csv_file,
            '.json': self._check_json_file,
            '.txt': self._check_text_file,
            '.py': self._check_python_file,
            '.sql': self._check_sql_file,
            '.xml': self._check_xml_file,
            '.zip': self._check_zip_file,
            '.pdf': self._check_pdf_file
        }
    
    def calculate_file_hash(self, file_path, algorithm='md5'):
        """Calcular hash do arquivo"""
        try:
            hash_func = hashlib.new(algorithm)
            with open(file_path, 'rb') as f:
                for chunk in iter(lambda: f.read(4096), b""):
                    hash_func.update(chunk)
            return hash_func.hexdigest()
        except Exception:
            return None
    
    def _check_basic_accessibility(self, file_path):
        """Verificação básica"""
        result = {
            'file_path': file_path,
            'file_name': os.path.basename(file_path),
            'file_size': 0,
            'is_accessible': False,
            'is_readable': False,
            'last_modified': '',
            'error': None
        }
        
        try:
            if not os.path.exists(file_path):
                result['error'] = 'Arquivo não encontrado'
                return result
            
            stat_info = os.stat(file_path)
            result['file_size'] = stat_info.st_size
            result['last_modified'] = datetime.fromtimestamp(stat_info.st_mtime).isoformat()
            result['is_accessible'] = True
            
            if os.access(file_path, os.R_OK):
                result['is_readable'] = True
        except Exception as e:
            result['error'] = str(e)
        
        return result
    
    def _check_csv_file(self, file_path):
        """Verificação CSV básica"""
        check = {'format_valid': False, 'rows_count': 0}
        try:
            encodings = ['utf-8', 'latin1', 'cp1252']
            for encoding in encodings:
                try:
                    with open(file_path, 'r', encoding=encoding) as f:
                        csv_reader = csv.reader(f)
                        rows = list(csv_reader)
                        check['format_valid'] = True
                        check['rows_count'] = len(rows)
                        check['encoding'] = encoding
                        break
                except UnicodeDecodeError:
                    continue
        except Exception as e:
            check['error'] = str(e)
        return check
    
    def _check_json_file(self, file_path):
        """Verificação JSON"""
        check = {'format_valid': False}
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                json.load(f)
                check['format_valid'] = True
                check['json_valid'] = True
        except json.JSONDecodeError as e:
            check['error'] = f"JSON inválido: {e}"
        except Exception as e:
            check['error'] = str(e)
        return check
    
    def _check_text_file(self, file_path):
        """Verificação texto"""
        check = {'format_valid': False, 'lines_count': 0}
        try:
            encodings = ['utf-8', 'latin1', 'cp1252']
            for encoding in encodings:
                try:
                    with open(file_path, 'r', encoding=encoding) as f:
                        lines = f.readlines()
                        check['format_valid'] = True
                        check['lines_count'] = len(lines)
                        check['encoding'] = encoding
                        break
                except UnicodeDecodeError:
                    continue
        except Exception as e:
            check['error'] = str(e)
        return check
    
    def _check_python_file(self, file_path):
        """Verificação Python"""
        check = {'format_valid': False, 'syntax_valid': False}
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            compile(content, file_path, 'exec')
            check['format_valid'] = True
            check['syntax_valid'] = True
        except SyntaxError as e:
            check['format_valid'] = True
            check['syntax_error'] = str(e)
        except Exception as e:
            check['error'] = str(e)
        return check
    
    def _check_sql_file(self, file_path):
        """Verificação SQL básica"""
        check = {'format_valid': False}
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            check['format_valid'] = True
            check['lines_count'] = len(content.splitlines())
        except Exception as e:
            check['error'] = str(e)
        return check
    
    def _check_xml_file(self, file_path):
        """Verificação XML básica"""
        check = {'format_valid': False}
        try:
            import xml.etree.ElementTree as ET
            ET.parse(file_path)
            check['format_valid'] = True
            check['well_formed'] = True
        except Exception as e:
            check['error'] = str(e)
        return check
    
    def _check_zip_file(self, file_path):
        """Verificação ZIP"""
        check = {'format_valid': False}
        try:
            with zipfile.ZipFile(file_path, 'r') as zip_file:
                bad_file = zip_file.testzip()
                check['format_valid'] = True
                check['is_corrupted'] = bad_file is not None
                check['files_count'] = len(zip_file.namelist())
        except Exception as e:
            check['error'] = str(e)
        return check
    
    def _check_pdf_file(self, file_path):
        """Verificação PDF básica"""
        check = {'format_valid': False}
        try:
            with open(file_path, 'rb') as f:
                header = f.read(8)
                if header.startswith(b'%PDF-'):
                    check['format_valid'] = True
                    check['pdf_version'] = header.decode('ascii', errors='ignore')
        except Exception as e:
            check['error'] = str(e)
        return check
    
    def check_file_integrity(self, file_path):
        """Verificar integridade de um arquivo"""
        result = self._check_basic_accessibility(file_path)
        
        if not result['is_accessible']:
            result['integrity_status'] = 'INACCESSIBLE'
            return result
        
        result['md5_hash'] = self.calculate_file_hash(file_path, 'md5')
        
        file_ext = Path(file_path).suffix.lower()
        if file_ext in self.file_handlers:
            specific_check = self.file_handlers[file_ext](file_path)
            result['specific_checks'] = specific_check
        else:
            result['specific_checks'] = {'format': 'unknown'}
        
        # Determinar status
        if result['is_readable']:
            if result['file_size'] == 0:
                result['integrity_status'] = 'UNKNOWN'
            elif 'specific_checks' in result and 'error' not in result['specific_checks']:
                result['integrity_status'] = 'INTACT'
            elif 'specific_checks' in result and 'error' in result['specific_checks']:
                result['integrity_status'] = 'CORRUPTED'
            else:
                result['integrity_status'] = 'INTACT'
        else:
            result['integrity_status'] = 'CORRUPTED'
        
        return result
    
    def scan_directories(self):
        """Escanear diretórios"""
        for directory in self.directories:
            if not os.path.exists(directory):
                continue
            
            for root, dirs, files in os.walk(directory):
                for file in files:
                    file_path = os.path.join(root, file)
                    try:
                        result = self.check_file_integrity(file_path)
                        self.results.append(result)
                        
                        self.summary['total_files'] += 1
                        if result['integrity_status'] == 'INTACT':
                            self.summary['intact_files'] += 1
                        elif result['integrity_status'] == 'CORRUPTED':
                            self.summary['corrupted_files'] += 1
                        elif result['integrity_status'] == 'INACCESSIBLE':
                            self.summary['inaccessible_files'] += 1
                            
                    except Exception:
                        continue
    
    def generate_text_report(self, output_name):
        """Gerar relatório em texto"""
        report_file = f"{output_name}.txt"
        
        with open(report_file, 'w', encoding='utf-8') as f:
            f.write("=" * 80 + "\\n")
            f.write("                RELATÓRIO DE INTEGRIDADE DE ARQUIVOS\\n")
            f.write("=" * 80 + "\\n\\n")
            
            f.write(f"Data: {self.summary['scan_date']}\\n")
            f.write(f"Total: {self.summary['total_files']}\\n")
            f.write(f"Íntegros: {self.summary['intact_files']}\\n")
            f.write(f"Corrompidos: {self.summary['corrupted_files']}\\n")
            f.write(f"Inacessíveis: {self.summary['inaccessible_files']}\\n\\n")
            
            # Arquivos corrompidos
            corrupted = [r for r in self.results if r['integrity_status'] == 'CORRUPTED']
            if corrupted:
                f.write("ARQUIVOS CORROMPIDOS:\\n")
                f.write("-" * 20 + "\\n")
                for i, result in enumerate(corrupted, 1):
                    f.write(f"{i}. {result['file_path']}\\n")
                    if result.get('error'):
                        f.write(f"   Erro: {result['error']}\\n")
                f.write("\\n")
            
            # Lista completa
            f.write("LISTA COMPLETA:\\n")
            f.write("-" * 15 + "\\n")
            status_symbols = {
                'INTACT': '✅',
                'CORRUPTED': '❌', 
                'INACCESSIBLE': '🚫',
                'UNKNOWN': '❓'
            }
            
            for result in sorted(self.results, key=lambda x: x['file_path']):
                symbol = status_symbols.get(result['integrity_status'], '?')
                f.write(f"{symbol} {result['file_path']}\\n")

class InteractiveFileChecker:
    """Interface interativa minima"""
    
    def __init__(self):
        self.directories = []
        self.output_name = None
    
    def print_header(self):
        print("=" * 60)
        print("🔍 VERIFICADOR DE INTEGRIDADE DE ARQUIVOS")
        print("=" * 60)
        print()
    
    def get_directories(self):
        while True:
            if not self.directories:
                print("Digite o diretório para verificar:")
                user_input = input(">>> ").strip()
                
                if not user_input:
                    print("❌ Diretório obrigatório!")
                    continue
                
                if os.path.exists(user_input):
                    self.directories.append(os.path.abspath(user_input))
                    print(f"✅ Adicionado: {user_input}")
                    break
                else:
                    print(f"❌ Diretório não encontrado: {user_input}")
            else:
                break
    
    def get_output_name(self):
        print("\\nNome do relatório (Enter para automático):")
        output_input = input(">>> ").strip()
        
        if not output_input:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            self.output_name = f"relatorio_integridade_{timestamp}"
        else:
            self.output_name = output_input
        
        print(f"✅ Relatório: {self.output_name}.txt")
    
    def execute_check(self):
        print("\\n🔍 Executando verificação...")
        
        checker = FileIntegrityChecker(self.directories)
        checker.scan_directories()
        checker.generate_text_report(self.output_name)
        
        print(f"\\n✅ Concluído!")
        print(f"Total: {checker.summary['total_files']}")
        print(f"Íntegros: {checker.summary['intact_files']}")
        print(f"Corrompidos: {checker.summary['corrupted_files']}")
        print(f"\\n📄 Relatório: {self.output_name}.txt")
    
    def run(self):
        try:
            self.print_header()
            self.get_directories()
            self.get_output_name()
            
            print("\\nProsseguir? (s/n): ", end="")
            if input().strip().lower() in ['', 's', 'sim']:
                self.execute_check()
            else:
                print("Cancelado.")
                
        except KeyboardInterrupt:
            print("\\n❌ Cancelado pelo usuário")
        except Exception as e:
            print(f"\\n❌ Erro: {e}")

def main():
    """Função principal"""
    try:
        checker = InteractiveFileChecker()
        checker.run()
        input("\\nPressione Enter para sair...")
    except Exception as e:
        print(f"Erro: {e}")
        input("Pressione Enter para sair...")

if __name__ == "__main__":
    main()
'''
    
    with open('verificador_minimo.py', 'w', encoding='utf-8') as f:
        f.write(script_minimo)
    
    print("✅ Script mínimo criado: verificador_minimo.py")
    return 'verificador_minimo.py'

def build_otimizado():
    """Build otimizado com tamanho reduzido"""
    
    print("🚀 BUILD OTIMIZADO - EXECUTÁVEL LEVE")
    print("=" * 38)
    
    # 1. Limpar builds anteriores
    if os.path.exists('build'):
        shutil.rmtree('build')
    if os.path.exists('dist'):
        shutil.rmtree('dist')
    
    # 2. Criar versão mínima
    script_minimo = criar_versao_minima()
    
    # 3. Build com exclusões
    print("\n🏗️  Criando executável otimizado...")
    
    cmd = [
        sys.executable, '-m', 'PyInstaller',
        '--onefile',
        '--console',
        '--name=VerificadorIntegridade_Minimo',
        '--clean',
        '--noconfirm',
        '--exclude-module=pandas',
        '--exclude-module=numpy',
        '--exclude-module=matplotlib',
        '--exclude-module=torch',
        '--exclude-module=scipy',
        '--exclude-module=PIL',
        '--exclude-module=cv2',
        '--exclude-module=sklearn',
        '--exclude-module=tensorflow',
        '--exclude-module=tkinter',
        '--exclude-module=PyQt5',
        '--exclude-module=PyQt6',
        '--exclude-module=PySide2',
        '--exclude-module=PySide6',
        script_minimo
    ]
    
    resultado = subprocess.run(cmd)
    
    if resultado.returncode == 0:
        # Verificar tamanho
        executavel = 'dist/VerificadorIntegridade_Minimo'
        if os.path.exists(executavel):
            tamanho = os.path.getsize(executavel) / (1024 * 1024)  # MB
            
            print(f"\\n✅ EXECUTÁVEL OTIMIZADO CRIADO!")
            print(f"📁 Local: {executavel}")
            print(f"📏 Tamanho: {tamanho:.1f} MB")
            print(f"\\n💡 Para testar: ./{executavel}")
            
            # Criar documentação
            criar_doc_executavel(executavel, tamanho)
            
            return True
        else:
            print("❌ Executável não encontrado")
            return False
    else:
        print("❌ Erro no build")
        return False

def criar_doc_executavel(executavel, tamanho_mb):
    """Criar documentação do executável"""
    
    doc = f"""# 🚀 VERIFICADOR DE INTEGRIDADE - EXECUTÁVEL STANDALONE

## ✅ Informações do Executável
- **Arquivo**: {os.path.basename(executavel)}
- **Tamanho**: {tamanho_mb:.1f} MB
- **Tipo**: Executável único standalone
- **Criado**: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}

## 🎯 Características
✅ **NÃO requer Python instalado na máquina**
✅ **Arquivo único** - baixar e executar
✅ **Otimizado** - tamanho reduzido
✅ **Interface interativa** simples
✅ **Relatórios em TXT**

## 🖥️ Como Usar

### Linux/macOS
```bash
chmod +x {os.path.basename(executavel)}
./{os.path.basename(executavel)}
```

### Windows
```cmd
{os.path.basename(executavel)}.exe
```

## 📋 Fluxo de Uso
1. Execute o arquivo
2. Digite o diretório para verificar
3. Digite nome do relatório (ou Enter para automático)
4. Confirme com 's' ou Enter
5. ✅ Relatório gerado em .txt

## 🔍 Status no Relatório
- ✅ Arquivo íntegro
- ❌ Arquivo corrompido  
- 🚫 Arquivo inacessível
- ❓ Status indeterminado

## 🆘 Solução de Problemas

### "Permissão negada"
```bash
chmod +x {os.path.basename(executavel)}
```

### Antivírus bloqueia
- Adicionar exceção para o arquivo
- Falso positivo comum em executáveis Python

### Arquivo não executa
- Verificar se o sistema é compatível
- Executar via terminal para ver erros

## 📊 Arquivos Suportados
- CSV, JSON, TXT, Python, SQL
- XML, ZIP, PDF (verificação básica)
- Qualquer arquivo (verificação geral)

## 🎉 Vantagens
- **Zero dependências** na máquina de destino
- **Fácil distribuição** - um arquivo só
- **Interface amigável** - perguntas simples
- **Relatórios claros** - formato texto
"""
    
    doc_file = f"{executavel}_GUIA.txt"
    with open(doc_file, 'w', encoding='utf-8') as f:
        f.write(doc)
    
    print(f"📋 Documentação criada: {os.path.basename(doc_file)}")

if __name__ == "__main__":
    build_otimizado()
# 🪟 GUIA COMPLETO - BUILD WINDOWS COM EXCEL

## 📋 Resumo dos Arquivos Necessários

### ✅ ARQUIVOS OBRIGATÓRIOS (copiar do Linux para Windows)
1. **script.py** - Engine principal com Excel support
2. **verificador_interativo.py** - Interface interativa  
3. **build_windows_excel.bat** - Script de build (criado automaticamente)

### 📖 ARQUIVOS RECOMENDADOS
4. **README.md** - Documentação geral
5. **EXCEL_FEATURES.md** - Documentação Excel
6. **requirements_windows.txt** - Lista de dependências (criado automaticamente)

### 🧪 ARQUIVOS DE TESTE (opcionais)  
7. **testar_excel_real.py** - Teste funcional Excel
8. **demonstracao_excel.py** - Demonstração completa

## 🚀 PROCESSO DE BUILD NO WINDOWS

### Passo 1: Preparar Ambiente
```cmd
# Verificar Python (mínimo 3.8)
python --version

# Atualizar pip
python -m pip install --upgrade pip
```

### Passo 2: Copiar Arquivos
```
Copiar do Linux → Windows:
├── script.py                    ← OBRIGATÓRIO
├── verificador_interativo.py    ← OBRIGATÓRIO  
├── README.md                    ← Recomendado
├── EXCEL_FEATURES.md            ← Recomendado
├── testar_excel_real.py         ← Opcional
└── demonstracao_excel.py        ← Opcional
```

### Passo 3: Executar Build
```cmd
# Método 1: Script automático (mais fácil)
build_windows_excel.bat

# Método 2: Manual
pip install pyinstaller pandas openpyxl
pyinstaller --onefile --name="VerificadorIntegridade_Excel" verificador_interativo.py

# Método 3: Com arquivo .spec (mais controle)
pyinstaller verificador_excel_windows.spec
```

### Passo 4: Testar Executável
```cmd
# Ir para diretório de saída
cd dist

# Testar executável
VerificadorIntegridade_Excel.exe

# Se der erro, testar com Python direto primeiro
python verificador_interativo.py
```

## 📦 RESULTADO ESPERADO

Após o build bem-sucedido:
```
dist/
├── VerificadorIntegridade_Excel.exe    ← Executável principal (~15-25MB)
└── extras/                             ← Arquivos adicionais
    ├── script.py                       ← Backup do engine
    ├── README.md                       ← Documentação
    └── EXCEL_FEATURES.md               ← Doc Excel
```

## ⚠️ TROUBLESHOOTING

### Erro: "pandas não encontrado"
```cmd
# Instalar pandas manualmente
pip install pandas openpyxl

# Verificar instalação
python -c "import pandas; print('pandas OK')"
```

### Erro: "PyInstaller não funciona"
```cmd
# Limpar cache PyInstaller
pyinstaller --clean verificador_interativo.py

# Ou usar método alternativo
pip install auto-py-to-exe
auto-py-to-exe
```

### Executável muito grande (>50MB)
```cmd
# Build otimizado
pyinstaller --onefile --optimize=2 --strip verificador_interativo.py
```

### Antivírus bloqueia executável
- Adicionar pasta dist/ às exceções do antivírus
- Usar certificado digital (para distribuição)
- Compilar em máquina limpa

## 🎯 ARQUIVOS MÍNIMOS PARA BUILD

**Para build básico (só precisar de 2 arquivos):**
1. `script.py`
2. `verificador_interativo.py`

**Comando mínimo:**
```cmd
pip install pyinstaller && pyinstaller --onefile verificador_interativo.py
```

## 📊 COMPARAÇÃO DE MÉTODOS

| Método | Tamanho | Velocidade | Excel Support | Facilidade |
|--------|---------|------------|---------------|------------|
| Script .bat | ~20MB | ⭐⭐⭐ | ✅ Completo | ⭐⭐⭐ Fácil |
| Manual PyInstaller | ~15MB | ⭐⭐ | ✅ Completo | ⭐⭐ Médio |
| Arquivo .spec | ~18MB | ⭐⭐⭐ | ✅ Completo | ⭐ Difícil |

---
📅 Versão: 20251016_1353
🎯 Funcionalidades Excel incluídas
⚡ Build otimizado para Windows

# ✅ CHECKLIST BUILD WINDOWS

## 📋 Antes de começar
- [ ] Python 3.8+ instalado no Windows
- [ ] pip funcionando (testar: `pip --version`)
- [ ] Conexão com internet ativa
- [ ] 10GB espaço livre temporário

## 📁 Arquivos necessários (verificar se existem)
- [ ] script.py
- [ ] verificador_interativo.py  
- [ ] build_windows_excel.bat
- [ ] requirements_windows.txt

## 🚀 Processo de Build
- [ ] 1. Copiar arquivos para pasta Windows
- [ ] 2. Abrir prompt comando (cmd) na pasta
- [ ] 3. Executar: `build_windows_excel.bat`
- [ ] 4. Aguardar conclusão (pode demorar 5-10 min)
- [ ] 5. Verificar se `dist\VerificadorIntegridade_Excel.exe` existe

## 🧪 Testar executável
- [ ] Executar: `dist\VerificadorIntegridade_Excel.exe`
- [ ] Verificar se interface abre corretamente
- [ ] Testar análise Excel (criar arquivo .xlsx teste)
- [ ] Verificar se pandas instala automaticamente

## ❌ Se algo der errado
- [ ] Consultar `GUIA_BUILD_WINDOWS.md`
- [ ] Testar Python direto: `python verificador_interativo.py`
- [ ] Verificar logs de erro
- [ ] Reinstalar dependências: `pip install -r requirements_windows.txt`

## ✅ Build bem-sucedido quando
- [ ] Executável criado (~15-25MB)
- [ ] Interface abre sem erros  
- [ ] Análise Excel funciona
- [ ] Dependências instalam automaticamente

#!/usr/bin/env python3
"""
Demonstração completa das funcionalidades Excel implementadas
"""

import tempfile
import os
import pandas as pd
from script import FileIntegrityChecker

def demonstracao_completa():
    """Demonstração completa das funcionalidades Excel"""
    
    print("🎯 DEMONSTRAÇÃO COMPLETA - FUNCIONALIDADES EXCEL")
    print("=" * 50)
    
    # Criar diretório temporário
    test_dir = tempfile.mkdtemp()
    print(f"📁 Diretório de teste: {test_dir}")
    
    # 1. Arquivo Excel válido
    print(f"\\n📊 1. CRIANDO ARQUIVO EXCEL VÁLIDO")
    valid_excel = os.path.join(test_dir, "dados_validos.xlsx")
    df_valid = pd.DataFrame({
        'ID': [1, 2, 3, 4, 5],
        'Nome': ['Alice', 'Bob', 'Carlos', 'Diana', 'Eduardo'],
        'Salario': [5000, 4500, 5500, 4800, 5200],
        'Departamento': ['TI', 'RH', 'Vendas', 'TI', 'Marketing']
    })
    df_valid.to_excel(valid_excel, index=False)
    
    # 2. Arquivo Excel com múltiplas planilhas
    print(f"📊 2. CRIANDO ARQUIVO EXCEL MULTI-PLANILHA")  
    multi_excel = os.path.join(test_dir, "relatorio_completo.xlsx")
    with pd.ExcelWriter(multi_excel, engine='openpyxl') as writer:
        # Planilha principal
        df_valid.to_excel(writer, sheet_name='Funcionarios', index=False)
        
        # Planilha financeira
        df_finance = pd.DataFrame({
            'Mes': ['Jan', 'Fev', 'Mar', 'Abr'],
            'Receita': [100000, 120000, 110000, 130000],
            'Despesas': [80000, 90000, 85000, 95000]
        })
        df_finance.to_excel(writer, sheet_name='Financeiro', index=False)
        
        # Planilha com dados ausentes
        df_missing = pd.DataFrame({
            'A': [1, None, 3, None, 5],
            'B': [None, 2, None, 4, None], 
            'C': [1, 2, 3, 4, 5]
        })
        df_missing.to_excel(writer, sheet_name='DadosAusentes', index=False)
        
        # Planilha vazia
        pd.DataFrame().to_excel(writer, sheet_name='Vazia', index=False)
    
    # 3. Arquivo corrompido (simular)
    print(f"🔧 3. CRIANDO ARQUIVO CORROMPIDO")
    corrupted_excel = os.path.join(test_dir, "corrompido.xlsx")
    with open(corrupted_excel, 'w') as f:
        f.write("Este não é um arquivo Excel válido!")
    
    # Testar verificador com todas as funcionalidades
    print(f"\\n🔍 INICIANDO VERIFICAÇÃO COMPLETA...")
    checker = FileIntegrityChecker([test_dir], auto_install_excel=True)
    
    arquivos_teste = [
        (valid_excel, "Excel Válido Simples"),
        (multi_excel, "Excel Multi-Planilha"),
        (corrupted_excel, "Arquivo Corrompido")
    ]
    
    for arquivo, descricao in arquivos_teste:
        print(f"\\n" + "="*60)
        print(f"📄 TESTANDO: {descricao}")
        print(f"📂 Arquivo: {os.path.basename(arquivo)}")
        print("="*60)
        
        result = checker.check_file_integrity(arquivo)
        
        # Mostrar informações básicas
        print(f"Status: {result['integrity_status']}")
        print(f"Tamanho: {result['file_size']} bytes")
        print(f"Hash: {result['md5_hash'][:16]}...")
        
        # Mostrar verificações específicas Excel
        if 'specific_checks' in result and result['specific_checks']:
            checks = result['specific_checks']
            print(f"\\n📊 ANÁLISE EXCEL:")
            
            print(f"  ✓ Formato válido: {checks.get('format_valid', 'N/A')}")
            print(f"  ✓ Nível verificação: {checks.get('verification_level', 'N/A')}")
            
            if 'pandas_version' in checks:
                print(f"  ✓ Pandas: {checks['pandas_version']}")
            
            if 'sheets_count' in checks:
                print(f"  ✓ Planilhas: {checks['sheets_count']}")
                
            if 'sheet_names' in checks:
                print(f"  ✓ Nomes: {', '.join(checks['sheet_names'])}")
            
            if 'sheets_info' in checks:
                print(f"\\n📋 DETALHES POR PLANILHA:")
                for sheet_name, info in checks['sheets_info'].items():
                    if 'error' not in info:
                        rows = info.get('rows', 0)
                        cols = info.get('columns', 0)
                        cells = info.get('cells', 0)
                        missing = info.get('missing_cells', 0)
                        missing_pct = info.get('missing_percentage', 0)
                        
                        print(f"    📄 {sheet_name}:")
                        print(f"       Dimensões: {rows}x{cols} ({cells} células)")
                        print(f"       Ausentes: {missing} ({missing_pct}%)")
                    else:
                        print(f"    ❌ {sheet_name}: {info['error']}")
            
            if 'total_cells' in checks:
                print(f"\\n📈 Total células analisadas: {checks['total_cells']}")
            
            if 'error' in checks:
                print(f"\\n❌ Erro: {checks['error']}")
            elif 'warning' in checks:
                print(f"\\n⚠️  Aviso: {checks['warning']}")
        else:
            print(f"\\n❌ Não foi possível analisar como Excel")
    
    # Limpeza
    print(f"\\n🧹 LIMPANDO ARQUIVOS TEMPORÁRIOS...")
    for arquivo, _ in arquivos_teste:
        if os.path.exists(arquivo):
            os.remove(arquivo)
    os.rmdir(test_dir)
    
    print(f"\\n✅ DEMONSTRAÇÃO COMPLETA FINALIZADA!")
    print(f"\\n🎉 FUNCIONALIDADES EXCEL TOTALMENTE OPERACIONAIS:")
    print("  ✨ Auto-detecção e instalação de dependências")
    print("  📊 Análise detalhada de planilhas múltiplas")
    print("  📈 Estatísticas de células e dados ausentes")
    print("  🛡️  Detecção de arquivos corrompidos")
    print("  ⚡ Performance otimizada para diferentes tamanhos")

if __name__ == "__main__":
    demonstracao_completa()